package bo.ucb.sis.proysisgis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProysisgisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProysisgisApplication.class, args);
	}

}
